"use client";

import { useState } from "react";
import { User01 } from "@untitledui/icons";
import type { Selection } from "react-aria-components";
import { useListData } from "react-stately";
import { MultiSelect } from "@/components/base/select/multi-select";
import { Select, type SelectItemType } from "@/components/base/select/select";
import { NativeSelect } from "@/components/base/select/select-native";
import { TagSelect } from "@/components/base/select/tag-select";
import { Dot } from "@/components/foundations/dot-icon";

const items: SelectItemType[] = [
    {
        label: "Phoenix Baker",
        id: "@phoenix",
        supportingText: "@phoenix",
        avatarUrl: "https://www.untitledui.com/images/avatars/phoenix-baker?fm=webp&q=80",
    },
    { label: "Olivia Rhye", id: "@olivia", supportingText: "@olivia", avatarUrl: "https://www.untitledui.com/images/avatars/olivia-rhye?fm=webp&q=80" },
    {
        label: "Lana Steiner",
        id: "@lana",
        supportingText: "@lana",

        avatarUrl: "https://www.untitledui.com/images/avatars/lana-steiner?fm=webp&q=80",
    },
    {
        label: "Demi Wilkinson",
        id: "@demi",
        supportingText: "@demi",
        avatarUrl: "https://www.untitledui.com/images/avatars/demi-wilkinson?fm=webp&q=80",
    },
    { label: "Candice Wu", id: "@candice", supportingText: "@candice", avatarUrl: "https://www.untitledui.com/images/avatars/candice-wu?fm=webp&q=80" },
    { label: "Natali Craig", id: "@natali", supportingText: "@natali", avatarUrl: "https://www.untitledui.com/images/avatars/natali-craig?fm=webp&q=80" },
    { label: "Abraham Baker", id: "@abraham", supportingText: "@abraham", avatarUrl: "https://www.untitledui.com/images/avatars/abraham-baker?fm=webp&q=80" },
    { label: "Adem Lane", id: "@adem", supportingText: "@adem", avatarUrl: "https://www.untitledui.com/images/avatars/adem-lane?fm=webp&q=80" },
    {
        label: "Jackson Reed",
        id: "@jackson",
        supportingText: "@jackson",
        avatarUrl: "https://www.untitledui.com/images/avatars/jackson-reed?fm=webp&q=80",
    },
    {
        label: "Jessie Meyton",
        id: "@jessie",
        supportingText: "@jessie",
        avatarUrl: "https://www.untitledui.com/images/avatars/jessie-meyton?fm=webp&q=80",
    },
];

export const DefaultDemo = () => {
    const items = [
        { label: "Phoenix Baker", id: "@phoenix", supportingText: "@phoenix" },
        { label: "Olivia Rhye", id: "@olivia", supportingText: "@olivia" },
        { label: "Lana Steiner", id: "@lana", supportingText: "@lana", disabled: true },
        { label: "Demi Wilkinson", id: "@demi", supportingText: "@demi" },
        { label: "Candice Wu", id: "@candice", supportingText: "@candice" },
        { label: "Natali Craig", id: "@natali", supportingText: "@natali" },
        { label: "Abraham Baker", id: "@abraham", supportingText: "@abraham" },
        { label: "Adem Lane", id: "@adem", supportingText: "@adem" },
        { label: "Jackson Reed", id: "@jackson", supportingText: "@jackson" },
        { label: "Jessie Meyton", id: "@jessie", supportingText: "@jessie" },
    ];

    return (
        <Select
            isRequired
            label="Team member"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Select team member"
            items={items}
        >
            {(item) => (
                <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                    {item.label}
                </Select.Item>
            )}
        </Select>
    );
};

export const DisabledDemo = () => {
    const items = [
        { label: "Phoenix Baker", id: "@phoenix", supportingText: "@phoenix" },
        { label: "Olivia Rhye", id: "@olivia", supportingText: "@olivia" },
        { label: "Lana Steiner", id: "@lana", supportingText: "@lana", disabled: true },
        { label: "Demi Wilkinson", id: "@demi", supportingText: "@demi" },
        { label: "Candice Wu", id: "@candice", supportingText: "@candice" },
        { label: "Natali Craig", id: "@natali", supportingText: "@natali" },
        { label: "Abraham Baker", id: "@abraham", supportingText: "@abraham" },
        { label: "Adem Lane", id: "@adem", supportingText: "@adem" },
        { label: "Jackson Reed", id: "@jackson", supportingText: "@jackson" },
        { label: "Jessie Meyton", id: "@jessie", supportingText: "@jessie" },
    ];

    return (
        <Select
            isRequired
            isDisabled
            label="Team member"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Select team member"
            items={items}
        >
            {(item) => (
                <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                    {item.label}
                </Select.Item>
            )}
        </Select>
    );
};

export const SizesDemo = () => {
    const items = [
        { label: "Phoenix Baker", id: "@phoenix", supportingText: "@phoenix" },
        { label: "Olivia Rhye", id: "@olivia", supportingText: "@olivia" },
        { label: "Lana Steiner", id: "@lana", supportingText: "@lana", disabled: true },
        { label: "Demi Wilkinson", id: "@demi", supportingText: "@demi" },
        { label: "Candice Wu", id: "@candice", supportingText: "@candice" },
        { label: "Natali Craig", id: "@natali", supportingText: "@natali" },
        { label: "Abraham Baker", id: "@abraham", supportingText: "@abraham" },
        { label: "Adem Lane", id: "@adem", supportingText: "@adem" },
        { label: "Jackson Reed", id: "@jackson", supportingText: "@jackson" },
        { label: "Jessie Meyton", id: "@jessie", supportingText: "@jessie" },
    ];

    return (
        <div className="flex flex-col gap-8">
            {/* Small */}
            <Select
                isRequired
                size="sm"
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>

            {/* Medium */}
            <Select
                isRequired
                size="md"
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>

            {/* Large */}
            <Select
                isRequired
                size="lg"
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
    );
};

export const IconLeadingDemo = () => {
    const items = [
        { label: "Phoenix Baker", id: "@phoenix", supportingText: "@phoenix", icon: User01 },
        { label: "Olivia Rhye", id: "@olivia", supportingText: "@olivia", icon: User01 },
        { label: "Lana Steiner", id: "@lana", supportingText: "@lana", icon: User01, disabled: true },
        { label: "Demi Wilkinson", id: "@demi", supportingText: "@demi", icon: User01 },
        { label: "Candice Wu", id: "@candice", supportingText: "@candice", icon: User01 },
        { label: "Natali Craig", id: "@natali", supportingText: "@natali", icon: User01 },
        { label: "Abraham Baker", id: "@abraham", supportingText: "@abraham", icon: User01 },
        { label: "Adem Lane", id: "@adem", supportingText: "@adem", icon: User01 },
        { label: "Jackson Reed", id: "@jackson", supportingText: "@jackson", icon: User01 },
        { label: "Jessie Meyton", id: "@jessie", supportingText: "@jessie", icon: User01 },
    ];

    return (
        <Select
            isRequired
            label="Team member"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Select team member"
            icon={User01}
            items={items}
        >
            {(item) => (
                <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                    {item.label}
                </Select.Item>
            )}
        </Select>
    );
};

export const AvatarLeadingDemo = () => {
    const items = [
        {
            label: "Phoenix Baker",
            id: "@phoenix",
            supportingText: "@phoenix",
            avatarUrl: "https://www.untitledui.com/images/avatars/phoenix-baker?fm=webp&q=80",
        },
        {
            label: "Olivia Rhye",
            id: "@olivia",
            supportingText: "@olivia",
            avatarUrl: "https://www.untitledui.com/images/avatars/olivia-rhye?fm=webp&q=80",
        },
        {
            label: "Lana Steiner",
            id: "@lana",
            supportingText: "@lana",

            avatarUrl: "https://www.untitledui.com/images/avatars/lana-steiner?fm=webp&q=80",
        },
        {
            label: "Demi Wilkinson",
            id: "@demi",
            supportingText: "@demi",
            avatarUrl: "https://www.untitledui.com/images/avatars/demi-wilkinson?fm=webp&q=80",
        },
        {
            label: "Candice Wu",
            id: "@candice",
            supportingText: "@candice",
            avatarUrl: "https://www.untitledui.com/images/avatars/candice-wu?fm=webp&q=80",
        },
        {
            label: "Natali Craig",
            id: "@natali",
            supportingText: "@natali",
            avatarUrl: "https://www.untitledui.com/images/avatars/natali-craig?fm=webp&q=80",
        },
        {
            label: "Abraham Baker",
            id: "@abraham",
            supportingText: "@abraham",
            avatarUrl: "https://www.untitledui.com/images/avatars/abraham-baker?fm=webp&q=80",
        },
        { label: "Adem Lane", id: "@adem", supportingText: "@adem", avatarUrl: "https://www.untitledui.com/images/avatars/adem-lane?fm=webp&q=80" },
        {
            label: "Jackson Reed",
            id: "@jackson",
            supportingText: "@jackson",
            avatarUrl: "https://www.untitledui.com/images/avatars/jackson-reed?fm=webp&q=80",
        },
        {
            label: "Jessie Meyton",
            id: "@jessie",
            supportingText: "@jessie",
            avatarUrl: "https://www.untitledui.com/images/avatars/jessie-meyton?fm=webp&q=80",
        },
    ];

    return (
        <Select
            isRequired
            label="Team member"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Select team member"
            icon={User01}
            items={items}
        >
            {(item) => (
                <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                    {item.label}
                </Select.Item>
            )}
        </Select>
    );
};

export const DotLeadingDemo = () => {
    const items: SelectItemType[] = [
        {
            label: "Phoenix Baker",
            id: "@phoenix",
            supportingText: "@phoenix",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Olivia Rhye",
            id: "@olivia",
            supportingText: "@olivia",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Lana Steiner",
            id: "@lana",
            supportingText: "@lana",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Demi Wilkinson",
            id: "@demi",
            supportingText: "@demi",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Candice Wu",
            id: "@candice",
            supportingText: "@candice",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Natali Craig",
            id: "@natali",
            supportingText: "@natali",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Abraham Baker",
            id: "@abraham",
            supportingText: "@abraham",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Adem Lane",
            id: "@adem",
            supportingText: "@adem",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Jackson Reed",
            id: "@jackson",
            supportingText: "@jackson",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
        {
            label: "Jessie Meyton",
            id: "@jessie",
            supportingText: "@jessie",
            icon: <Dot className="size-2.5 text-fg-success-secondary" />,
        },
    ];

    return (
        <Select
            isRequired
            label="Team member"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Select team member"
            icon={<Dot className="size-2.5 text-fg-success-secondary" />}
            items={items}
        >
            {(item) => (
                <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                    {item.label}
                </Select.Item>
            )}
        </Select>
    );
};

export const SearchDemo = () => {
    const items = [
        { label: "Phoenix Baker", id: "@phoenix", supportingText: "@phoenix" },
        { label: "Olivia Rhye", id: "@olivia", supportingText: "@olivia" },
        { label: "Lana Steiner", id: "@lana", supportingText: "@lana", disabled: true },
        { label: "Demi Wilkinson", id: "@demi", supportingText: "@demi" },
        { label: "Candice Wu", id: "@candice", supportingText: "@candice" },
        { label: "Natali Craig", id: "@natali", supportingText: "@natali" },
        { label: "Abraham Baker", id: "@abraham", supportingText: "@abraham" },
        { label: "Adem Lane", id: "@adem", supportingText: "@adem" },
        { label: "Jackson Reed", id: "@jackson", supportingText: "@jackson" },
        { label: "Jessie Meyton", id: "@jessie", supportingText: "@jessie" },
    ];

    return (
        <Select.ComboBox isRequired label="Search" tooltip="This is a tooltip" hint="This is a hint text to help user." placeholder="Search" items={items}>
            {(item) => (
                <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                    {item.label}
                </Select.Item>
            )}
        </Select.ComboBox>
    );
};

export const TagsDemo = () => {
    const selectedItems = useListData<SelectItemType>({
        initialItems: [],
    });

    const items: (SelectItemType & { disabled?: boolean })[] = [
        {
            label: "Phoenix Baker",
            id: "@phoenix",
            supportingText: "@phoenix",
            avatarUrl: "https://www.untitledui.com/images/avatars/phoenix-baker?fm=webp&q=80",
        },
        { label: "Olivia Rhye", id: "@olivia", supportingText: "@olivia", avatarUrl: "https://www.untitledui.com/images/avatars/olivia-rhye?fm=webp&q=80" },
        {
            label: "Lana Steiner",
            id: "@lana",
            supportingText: "@lana",
            disabled: true,
            avatarUrl: "https://www.untitledui.com/images/avatars/lana-steiner?fm=webp&q=80",
        },
        { label: "Demi Wilkinson", id: "@demi", supportingText: "@demi", avatarUrl: "https://www.untitledui.com/images/avatars/demi-wilkinson?fm=webp&q=80" },
        { label: "Candice Wu", id: "@candice", supportingText: "@candice", avatarUrl: "https://www.untitledui.com/images/avatars/candice-wu?fm=webp&q=80" },
        { label: "Natali Craig", id: "@natali", supportingText: "@natali", avatarUrl: "https://www.untitledui.com/images/avatars/natali-craig?fm=webp&q=80" },
        {
            label: "Abraham Baker",
            id: "@abraham",
            supportingText: "@abraham",
            avatarUrl: "https://www.untitledui.com/images/avatars/abraham-baker?fm=webp&q=80",
        },
        { label: "Adem Lane", id: "@adem", supportingText: "@adem", avatarUrl: "https://www.untitledui.com/images/avatars/adem-lane?fm=webp&q=80" },
        { label: "Jackson Reed", id: "@jackson", supportingText: "@jackson", avatarUrl: "https://www.untitledui.com/images/avatars/jackson-reed?fm=webp&q=80" },
        { label: "Jessie Meyton", id: "@jessie", supportingText: "@jessie", avatarUrl: "https://www.untitledui.com/images/avatars/jessie-meyton?fm=webp&q=80" },
    ];

    return (
        <TagSelect
            isRequired
            size="md"
            selectedItems={selectedItems}
            label="Search"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Search"
            items={items}
        >
            {(item) => (
                <TagSelect.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                    {item.label}
                </TagSelect.Item>
            )}
        </TagSelect>
    );
};

export const Native = () => (
    <NativeSelect
        label="Team members"
        options={[
            { label: "Wade Cooper", value: "@wadecooper" },
            { label: "Arlene Mccoy", value: "@arlenemccoy" },
            { label: "Devon Webb", value: "@devonwebb", disabled: true },
            { label: "Tom Cook", value: "@tomcook" },
            { label: "Tanya Fox", value: "@tanyafox" },
            { label: "Hellen Schmidt", value: "@hellenschmidt" },
            { label: "Caroline Schultz", value: "@carolineschultz" },
            { label: "Mason Heaney", value: "@masonheaney" },
            { label: "Claudie Smitham", value: "@claudiesmitham" },
            { label: "Emil Schaefer", value: "@emilschaefer" },
        ]}
        hint="This is a hint text to help user."
    />
);

export const Default = () => {
    return (
        <div className="flex flex-col gap-16">
            <div className="flex flex-col gap-4">
                <Select
                    isRequired
                    label="Team member"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Select team member"
                    items={items.map(({ avatarUrl: _, ...item }) => item)}
                >
                    {(item) => (
                        <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                            {item.label}
                        </Select.Item>
                    )}
                </Select>
                <Select
                    isDisabled
                    isRequired
                    label="Team member"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Select team member"
                    items={items.map(({ avatarUrl: _, ...item }) => item)}
                >
                    {(item) => (
                        <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                            {item.label}
                        </Select.Item>
                    )}
                </Select>
            </div>
            <div className="flex flex-col gap-4">
                <Select
                    isRequired
                    size="md"
                    label="Team member"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Select team member"
                    items={items.map(({ avatarUrl: _, ...item }) => item)}
                >
                    {(item) => (
                        <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                            {item.label}
                        </Select.Item>
                    )}
                </Select>
                <Select
                    isDisabled
                    isRequired
                    size="md"
                    label="Team member"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Select team member"
                    items={items.map(({ avatarUrl: _, ...item }) => item)}
                >
                    {(item) => (
                        <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                            {item.label}
                        </Select.Item>
                    )}
                </Select>
            </div>
            <div className="flex flex-col gap-4">
                <Select
                    isRequired
                    size="lg"
                    label="Team member"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Select team member"
                    items={items.map(({ avatarUrl: _, ...item }) => item)}
                >
                    {(item) => (
                        <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                            {item.label}
                        </Select.Item>
                    )}
                </Select>
                <Select
                    isDisabled
                    isRequired
                    size="lg"
                    label="Team member"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Select team member"
                    items={items.map(({ avatarUrl: _, ...item }) => item)}
                >
                    {(item) => (
                        <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                            {item.label}
                        </Select.Item>
                    )}
                </Select>
            </div>
        </div>
    );
};

export const IconLeading = () => (
    <div className="flex flex-col gap-16">
        <div className="flex flex-col gap-4">
            <Select
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                items={items.map(({ avatarUrl: _, ...item }) => ({ ...item, icon: User01 }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                isDisabled
                items={items.map(({ avatarUrl: _, ...item }) => ({ ...item, icon: User01 }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
        <div className="flex flex-col gap-4">
            <Select
                size="md"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                items={items.map(({ avatarUrl: _, ...item }) => ({ ...item, icon: User01 }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                size="md"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                isDisabled
                items={items.map(({ avatarUrl: _, ...item }) => ({ ...item, icon: User01 }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
        <div className="flex flex-col gap-4">
            <Select
                size="lg"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                items={items.map(({ avatarUrl: _, ...item }) => ({ ...item, icon: User01 }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                size="lg"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                isDisabled
                items={items.map(({ avatarUrl: _, ...item }) => ({ ...item, icon: User01 }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
    </div>
);

export const AvatarLeading = () => (
    <div className="flex flex-col gap-16">
        <div className="flex flex-col gap-4">
            <Select
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                isDisabled
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
        <div className="flex flex-col gap-4">
            <Select
                size="md"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                size="md"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                isDisabled
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
        <div className="flex flex-col gap-4">
            <Select
                size="lg"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                size="lg"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={User01}
                isDisabled
                items={items}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
    </div>
);

export const DotLeading = () => (
    <div className="flex flex-col gap-16">
        <div className="flex flex-col gap-4">
            <Select
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={<Dot className="size-2 text-fg-success-secondary" />}
                items={items.map(({ avatarUrl: _, ...item }) => ({
                    ...item,
                    icon: <Dot className="size-2 text-fg-success-secondary" />,
                }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                isDisabled
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={<Dot className="size-2 text-fg-success-secondary" />}
                items={items.map(({ avatarUrl: _, ...item }) => ({
                    ...item,
                    icon: <Dot className="size-2 text-fg-success-secondary" />,
                }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
        <div className="flex flex-col gap-4">
            <Select
                size="md"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={<Dot className="size-2.5 text-fg-success-secondary" />}
                items={items.map(({ avatarUrl: _, ...item }) => ({
                    ...item,
                    icon: <Dot className="size-2.5 text-fg-success-secondary" />,
                }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                isDisabled
                isRequired
                size="md"
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={<Dot className="size-2.5 text-fg-success-secondary" />}
                items={items.map(({ avatarUrl: _, ...item }) => ({
                    ...item,
                    icon: <Dot className="size-2.5 text-fg-success-secondary" />,
                }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
        <div className="flex flex-col gap-4">
            <Select
                size="lg"
                isRequired
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={<Dot className="size-2.5 text-fg-success-secondary" />}
                items={items.map(({ avatarUrl: _, ...item }) => ({
                    ...item,
                    icon: <Dot className="size-2.5 text-fg-success-secondary" />,
                }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
            <Select
                isDisabled
                isRequired
                size="lg"
                label="Team member"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select team member"
                icon={<Dot className="size-2.5 text-fg-success-secondary" />}
                items={items.map(({ avatarUrl: _, ...item }) => ({
                    ...item,
                    icon: <Dot className="size-2.5 text-fg-success-secondary" />,
                }))}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select>
        </div>
    </div>
);

export const Search = () => (
    <div className="flex flex-col gap-16">
        <div className="flex flex-col gap-4">
            <Select.ComboBox
                isRequired
                label="Search"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Search"
                items={items.map(({ avatarUrl: _, ...item }) => item)}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select.ComboBox>
            <Select.ComboBox
                isRequired
                label="Search"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Search"
                isDisabled
                items={items.map(({ avatarUrl: _, ...item }) => item)}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select.ComboBox>
        </div>
        <div className="flex flex-col gap-4">
            <Select.ComboBox
                size="md"
                isRequired
                label="Search"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Search"
                items={items.map(({ avatarUrl: _, ...item }) => item)}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select.ComboBox>
            <Select.ComboBox
                size="md"
                isRequired
                label="Search"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Search"
                isDisabled
                items={items.map(({ avatarUrl: _, ...item }) => item)}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select.ComboBox>
        </div>
        <div className="flex flex-col gap-4">
            <Select.ComboBox
                size="lg"
                isRequired
                label="Search"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Search"
                items={items.map(({ avatarUrl: _, ...item }) => item)}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select.ComboBox>
            <Select.ComboBox
                size="lg"
                isRequired
                label="Search"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Search"
                isDisabled
                items={items.map(({ avatarUrl: _, ...item }) => item)}
            >
                {(item) => (
                    <Select.Item id={item.id} supportingText={item.supportingText} isDisabled={item.isDisabled} icon={item.icon} avatarUrl={item.avatarUrl}>
                        {item.label}
                    </Select.Item>
                )}
            </Select.ComboBox>
        </div>
    </div>
);

export const Tags = () => {
    const selectedItems = useListData<SelectItemType>({
        initialItems: [],
    });

    return (
        <div className="flex flex-col gap-16">
            <div className="flex flex-col gap-4">
                <TagSelect
                    shortcut
                    selectedItems={selectedItems}
                    isRequired
                    label="Search"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Search"
                    items={items}
                >
                    {(item) => (
                        <TagSelect.Item
                            id={item.id}
                            supportingText={item.supportingText}
                            isDisabled={item.isDisabled}
                            icon={item.icon}
                            avatarUrl={item.avatarUrl}
                        >
                            {item.label}
                        </TagSelect.Item>
                    )}
                </TagSelect>

                <TagSelect
                    shortcut
                    selectedItems={selectedItems}
                    isRequired
                    label="Search"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Search"
                    items={items}
                    isDisabled
                >
                    {(item) => (
                        <TagSelect.Item
                            id={item.id}
                            supportingText={item.supportingText}
                            isDisabled={item.isDisabled}
                            icon={item.icon}
                            avatarUrl={item.avatarUrl}
                        >
                            {item.label}
                        </TagSelect.Item>
                    )}
                </TagSelect>
            </div>
            <div className="flex flex-col gap-4">
                <TagSelect
                    shortcut
                    selectedItems={selectedItems}
                    size="md"
                    isRequired
                    label="Search"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    items={items}
                    placeholder="Search"
                >
                    {(item) => (
                        <TagSelect.Item
                            id={item.id}
                            supportingText={item.supportingText}
                            isDisabled={item.isDisabled}
                            icon={item.icon}
                            avatarUrl={item.avatarUrl}
                        >
                            {item.label}
                        </TagSelect.Item>
                    )}
                </TagSelect>
                <TagSelect
                    shortcut
                    selectedItems={selectedItems}
                    size="md"
                    isRequired
                    label="Search"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Search"
                    items={items}
                    isDisabled
                >
                    {(item) => (
                        <TagSelect.Item
                            id={item.id}
                            supportingText={item.supportingText}
                            isDisabled={item.isDisabled}
                            icon={item.icon}
                            avatarUrl={item.avatarUrl}
                        >
                            {item.label}
                        </TagSelect.Item>
                    )}
                </TagSelect>
            </div>
            <div className="flex flex-col gap-4">
                <TagSelect
                    shortcut
                    selectedItems={selectedItems}
                    size="lg"
                    isRequired
                    label="Search"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    items={items}
                    placeholder="Search"
                >
                    {(item) => (
                        <TagSelect.Item
                            id={item.id}
                            supportingText={item.supportingText}
                            isDisabled={item.isDisabled}
                            icon={item.icon}
                            avatarUrl={item.avatarUrl}
                        >
                            {item.label}
                        </TagSelect.Item>
                    )}
                </TagSelect>
                <TagSelect
                    shortcut
                    selectedItems={selectedItems}
                    size="lg"
                    isRequired
                    label="Search"
                    tooltip="This is a tooltip"
                    hint="This is a hint text to help user."
                    placeholder="Search"
                    items={items}
                    isDisabled
                >
                    {(item) => (
                        <TagSelect.Item
                            id={item.id}
                            supportingText={item.supportingText}
                            isDisabled={item.isDisabled}
                            icon={item.icon}
                            avatarUrl={item.avatarUrl}
                        >
                            {item.label}
                        </TagSelect.Item>
                    )}
                </TagSelect>
            </div>
        </div>
    );
};

const teamItems: SelectItemType[] = [
    { id: "engineering", label: "Engineering", supportingText: "12 users" },
    { id: "design", label: "Design", supportingText: "10 users" },
    { id: "product", label: "Product", supportingText: "6 users" },
    { id: "marketing", label: "Marketing", supportingText: "8 users" },
    { id: "sales", label: "Sales", supportingText: "12 users" },
    { id: "customer-success", label: "Customer Success", supportingText: "4 users" },
    { id: "operations", label: "Operations", supportingText: "2 users" },
    { id: "finance", label: "Finance", supportingText: "2 users" },
];

const getSelectedUserCount = (selectedKeys: Selection) => {
    if (selectedKeys === "all") return teamItems.reduce((sum, t) => sum + parseInt(t.supportingText?.split(" ")[0] || "0"), 0);
    const selected = teamItems.filter((t) => (selectedKeys as Set<string | number>).has(t.id));
    return selected.reduce((sum, t) => sum + parseInt(t.supportingText?.split(" ")[0] || "0"), 0);
};

export const MultiSelectSmDemo = () => {
    const [selectedKeys, setSelectedKeys] = useState<Selection>(new Set(["design", "product"]));

    return (
        <MultiSelect
            isRequired
            size="sm"
            label="Teams"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Select teams"
            items={teamItems}
            selectedKeys={selectedKeys}
            onSelectionChange={setSelectedKeys}
            supportingText={`${getSelectedUserCount(selectedKeys)} users`}
            onReset={() => setSelectedKeys(new Set())}
            onSelectAll={() => setSelectedKeys(new Set(teamItems.map((t) => t.id)))}
        >
            {(item) => (
                <MultiSelect.Item id={item.id} supportingText={item.supportingText} selectionIndicator="checkbox" selectionIndicatorAlign="left">
                    {item.label}
                </MultiSelect.Item>
            )}
        </MultiSelect>
    );
};

export const MultiSelectMdDemo = () => {
    const [selectedKeys, setSelectedKeys] = useState<Selection>(new Set(["design", "product"]));

    return (
        <MultiSelect
            isRequired
            size="md"
            label="Teams"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Select teams"
            items={teamItems}
            selectedKeys={selectedKeys}
            onSelectionChange={setSelectedKeys}
            supportingText={`${getSelectedUserCount(selectedKeys)} users`}
            onReset={() => setSelectedKeys(new Set())}
            onSelectAll={() => setSelectedKeys(new Set(teamItems.map((t) => t.id)))}
        >
            {(item) => (
                <MultiSelect.Item id={item.id} supportingText={item.supportingText} selectionIndicator="checkbox" selectionIndicatorAlign="left">
                    {item.label}
                </MultiSelect.Item>
            )}
        </MultiSelect>
    );
};

export const MultiSelectWithIconDemo = () => {
    const [selectedKeys, setSelectedKeys] = useState<Selection>(new Set(["design"]));

    return (
        <MultiSelect
            size="md"
            label="Assignees"
            hint="Add one or more teammates."
            placeholder="Select assignees"
            icon={User01}
            items={teamItems}
            selectedKeys={selectedKeys}
            onSelectionChange={setSelectedKeys}
            supportingText={`${getSelectedUserCount(selectedKeys)} users`}
            onReset={() => setSelectedKeys(new Set())}
            onSelectAll={() => setSelectedKeys(new Set(teamItems.map((t) => t.id)))}
        >
            {(item) => (
                <MultiSelect.Item id={item.id} supportingText={item.supportingText} selectionIndicator="checkbox" selectionIndicatorAlign="left">
                    {item.label}
                </MultiSelect.Item>
            )}
        </MultiSelect>
    );
};

export const MultiSelectLgDemo = () => {
    const [selectedKeys, setSelectedKeys] = useState<Selection>(new Set(["design", "product"]));

    return (
        <MultiSelect
            isRequired
            size="lg"
            label="Teams"
            tooltip="This is a tooltip"
            hint="This is a hint text to help user."
            placeholder="Select teams"
            items={teamItems}
            selectedKeys={selectedKeys}
            onSelectionChange={setSelectedKeys}
            supportingText={`${getSelectedUserCount(selectedKeys)} users`}
            onReset={() => setSelectedKeys(new Set())}
            onSelectAll={() => setSelectedKeys(new Set(teamItems.map((t) => t.id)))}
        >
            {(item) => (
                <MultiSelect.Item id={item.id} supportingText={item.supportingText} selectionIndicator="checkbox" selectionIndicatorAlign="left">
                    {item.label}
                </MultiSelect.Item>
            )}
        </MultiSelect>
    );
};

export const MultiSelectSizesDemo = () => {
    const [smKeys, setSmKeys] = useState<Selection>(new Set(["design", "product"]));
    const [mdKeys, setMdKeys] = useState<Selection>(new Set(["design", "product"]));
    const [lgKeys, setLgKeys] = useState<Selection>(new Set(["design", "product"]));

    const renderItem = (item: SelectItemType) => (
        <MultiSelect.Item id={item.id} supportingText={item.supportingText} selectionIndicator="checkbox" selectionIndicatorAlign="left">
            {item.label}
        </MultiSelect.Item>
    );

    return (
        <div className="flex flex-col gap-8">
            {/* Small */}
            <MultiSelect
                isRequired
                size="sm"
                label="Teams"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select teams"
                items={teamItems}
                selectedKeys={smKeys}
                onSelectionChange={setSmKeys}
                supportingText={`${getSelectedUserCount(smKeys)} users`}
                onReset={() => setSmKeys(new Set())}
                onSelectAll={() => setSmKeys(new Set(teamItems.map((t) => t.id)))}
            >
                {renderItem}
            </MultiSelect>

            {/* Medium */}
            <MultiSelect
                isRequired
                size="md"
                label="Teams"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select teams"
                items={teamItems}
                selectedKeys={mdKeys}
                onSelectionChange={setMdKeys}
                supportingText={`${getSelectedUserCount(mdKeys)} users`}
                onReset={() => setMdKeys(new Set())}
                onSelectAll={() => setMdKeys(new Set(teamItems.map((t) => t.id)))}
            >
                {renderItem}
            </MultiSelect>

            {/* Large */}
            <MultiSelect
                isRequired
                size="lg"
                label="Teams"
                tooltip="This is a tooltip"
                hint="This is a hint text to help user."
                placeholder="Select teams"
                items={teamItems}
                selectedKeys={lgKeys}
                onSelectionChange={setLgKeys}
                supportingText={`${getSelectedUserCount(lgKeys)} users`}
                onReset={() => setLgKeys(new Set())}
                onSelectAll={() => setLgKeys(new Set(teamItems.map((t) => t.id)))}
            >
                {renderItem}
            </MultiSelect>
        </div>
    );
};

export const MultiSelectDisabledDemo = () => (
    <MultiSelect
        size="md"
        label="Teams"
        tooltip="This is a tooltip"
        hint="This is a hint text to help user."
        placeholder="Select teams"
        items={teamItems}
        isDisabled
    >
        {(item) => (
            <MultiSelect.Item id={item.id} supportingText={item.supportingText} selectionIndicator="checkbox" selectionIndicatorAlign="left">
                {item.label}
            </MultiSelect.Item>
        )}
    </MultiSelect>
);
