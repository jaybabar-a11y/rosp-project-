import nextPlugin from "@next/eslint-plugin-next";
import tsPlugin from "@typescript-eslint/eslint-plugin";
import tsParser from "@typescript-eslint/parser";
import jsxA11yPlugin from "eslint-plugin-jsx-a11y";
import prettierPlugin from "eslint-plugin-prettier";
import reactPlugin from "eslint-plugin-react";
import reactHooksPlugin from "eslint-plugin-react-hooks";
import storybook from "eslint-plugin-storybook";
import unusedImports from "eslint-plugin-unused-imports";

export default [
    { ignores: ["node_modules/*", "storybook-addon-pixel-perfect/dist"] },
    { files: ["**/*.{js,jsx,ts,tsx}"], ...reactPlugin.configs.flat.recommended },
    {
        settings: {
            react: {
                // Pinned explicitly (not "detect"): eslint-plugin-react@7.37.5's version
                // auto-detection calls context.getFilename(), which ESLint 10 removed.
                version: "19.2",
            },
        },
        files: ["**/*.{js,jsx,ts,tsx}"],
        languageOptions: {
            parser: tsParser,
            parserOptions: {
                ecmaVersion: "latest",
                sourceType: "module",
                ecmaFeatures: {
                    jsx: true,
                },
            },
        },
        plugins: {
            "@typescript-eslint": tsPlugin,
            prettier: prettierPlugin,
            "unused-imports": unusedImports,
            react: reactPlugin,
            "react-hooks": reactHooksPlugin,
            "jsx-a11y": jsxA11yPlugin,
            "@next/next": nextPlugin,
        },
        rules: {
            "unused-imports/no-unused-imports": "error",
            // Forbid importing from packages that are only present as hoisted transitive
            // dependencies. They type-check locally but fail on a clean or non-hoisting install.
            "no-restricted-imports": [
                "error",
                {
                    patterns: [
                        {
                            group: ["@react-types/*"],
                            message: "Import types from react-aria or react-aria-components instead; @react-types/* is not a declared dependency.",
                        },
                        {
                            group: ["@storybook/nextjs", "@storybook/nextjs/*", "@storybook/react", "@storybook/react/*"],
                            message: "Import from @storybook/nextjs-vite instead; it is the declared Storybook framework package.",
                        },
                    ],
                },
            ],
            // The rules below match what a consumer's default config enables (create-next-app ships
            // eslint-config-next: react-hooks "recommended-latest" and typescript-eslint "recommended").
            // Components are copied into those projects, so anything looser here ships lint errors to them.
            "@typescript-eslint/no-explicit-any": "error",
            "@typescript-eslint/no-empty-object-type": "error",
            "prefer-const": "error",

            "@typescript-eslint/consistent-type-imports": [
                "error",
                {
                    prefer: "type-imports",
                    fixStyle: "separate-type-imports",
                    disallowTypeAnnotations: true,
                },
            ],

            // React Hooks rules, including the React Compiler checks (refs, set-state-in-effect, ...).
            ...reactHooksPlugin.configs["recommended-latest"].rules,

            // Next.js rules (disabled for component library)
            "@next/next/no-img-element": "off",
            "@next/next/no-html-link-for-pages": "off",

            "prettier/prettier": [
                "warn",
                {},
                {
                    usePrettierrc: true,
                },
            ],
            "react/react-in-jsx-scope": "off",
            "react/display-name": "off",
            "react/jsx-key": "warn",
            "react/prop-types": "off",
            // Off on purpose: thousands of examples use plain apostrophes in JSX text.
            "react/no-unescaped-entities": "off",
            "react/no-unknown-property": ["error", { ignore: ["fill"] }],
            "no-unused-vars": ["warn", { argsIgnorePattern: "^_" }],
            "@typescript-eslint/no-unused-vars": ["warn", { argsIgnorePattern: "^_", varsIgnorePattern: "^_" }],
            "no-undef": "off",
            "no-redeclare": "warn",
            "max-len": "off",
            "jsx-a11y/alt-text": "error",
        },
    },
    ...storybook.configs["flat/recommended"],
];
